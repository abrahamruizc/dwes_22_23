let numero = Math.floor( Math.random() * (50 - 1) + 1);
console.log(numero);

let pregunta= parseInt(prompt("numero"));
console.log(pregunta);

while(pregunta == isNaN() || pregunta == NaN){
    pregunta = parseInt(prompt("introduce un numero"));
    console.log(pregunta);

    if (pregunta === numero){
        break;
    }

}

//document.write("");






